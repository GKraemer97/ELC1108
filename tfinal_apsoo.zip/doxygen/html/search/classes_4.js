var searchData=
[
  ['leitor_0',['Leitor',['../classapplication_1_1_leitor.html',1,'application']]]
];
