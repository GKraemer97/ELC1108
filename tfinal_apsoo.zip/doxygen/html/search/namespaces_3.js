var searchData=
[
  ['facade_0',['facade',['../namespacefacade.html',1,'']]]
];
