var searchData=
[
  ['inicializarsubsistemas_0',['inicializarSubsistemas',['../classfacade_1_1_app_facade.html#a10e9b062c24d559d53824982842e0d5c',1,'facade::AppFacade']]],
  ['input_1',['input',['../classapplication_1_1_leitor.html#aae84022ed3aef635f08d6b1a66655084',1,'application::Leitor']]]
];
