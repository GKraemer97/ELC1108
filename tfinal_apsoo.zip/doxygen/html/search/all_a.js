var searchData=
[
  ['nome_0',['nome',['../classbridge_1_1_produto.html#a83a94b2b644a672b190288607b61d9ee',1,'bridge.Produto.nome()'],['../classbridge_1_1_restaurante.html#a190df22d83f5184df060c6d180b20253',1,'bridge.Restaurante.nome()']]],
  ['nomedoprato_1',['nomeDoPrato',['../classstate_1_1_pedido.html#ad1afc9041b7a3ddb59faae7acf55c171',1,'state::Pedido']]]
];
