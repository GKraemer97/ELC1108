var searchData=
[
  ['input_0',['input',['../classapplication_1_1_leitor.html#aae84022ed3aef635f08d6b1a66655084',1,'application::Leitor']]]
];
