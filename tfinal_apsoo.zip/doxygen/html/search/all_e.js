var searchData=
[
  ['tamanhocardapio_0',['tamanhoCardapio',['../interfacebridge_1_1_cardapio.html#a6006189833ee80d59ffd76288d25e545',1,'bridge.Cardapio.tamanhoCardapio()'],['../classbridge_1_1_cardapio_gaucho.html#a785f34d4b6095da352d7446dac27c83d',1,'bridge.CardapioGaucho.tamanhoCardapio()'],['../classbridge_1_1_cardapio_texano.html#ab3ade597df27174deaeefd5204b94fe8',1,'bridge.CardapioTexano.tamanhoCardapio()']]]
];
