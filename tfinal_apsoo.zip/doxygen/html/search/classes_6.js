var searchData=
[
  ['restaurante_0',['Restaurante',['../classbridge_1_1_restaurante.html',1,'bridge']]],
  ['restaurantebr_1',['RestauranteBr',['../classbridge_1_1_restaurante_br.html',1,'bridge']]],
  ['restauranteeua_2',['RestauranteEua',['../classbridge_1_1_restaurante_eua.html',1,'bridge']]]
];
