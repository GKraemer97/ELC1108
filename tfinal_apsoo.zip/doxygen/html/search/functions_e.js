var searchData=
[
  ['vinter_0',['VinteR',['../classchain_of_responsability_1_1_vinte_r.html#ac8eb2fdcef0c17da18ef410e3913c9f0',1,'chainOfResponsability::VinteR']]]
];
