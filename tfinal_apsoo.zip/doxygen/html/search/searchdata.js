var indexSectionsWithContent =
{
  0: "abcdefgilmnprstuv",
  1: "acdelprsuv",
  2: "abcfs",
  3: "acdelprsuv",
  4: "acdefgilmprstuv",
  5: "cefinprv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Namespaces",
  3: "Arquivos",
  4: "Funções",
  5: "Variáveis"
};

