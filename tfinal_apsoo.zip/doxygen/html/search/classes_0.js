var searchData=
[
  ['appfacade_0',['AppFacade',['../classfacade_1_1_app_facade.html',1,'facade']]]
];
