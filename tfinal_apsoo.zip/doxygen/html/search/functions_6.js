var searchData=
[
  ['inicializarsubsistemas_0',['inicializarSubsistemas',['../classfacade_1_1_app_facade.html#a10e9b062c24d559d53824982842e0d5c',1,'facade::AppFacade']]]
];
