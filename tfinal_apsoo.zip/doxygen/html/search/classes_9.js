var searchData=
[
  ['vinter_0',['VinteR',['../classchain_of_responsability_1_1_vinte_r.html',1,'chainOfResponsability']]]
];
