var searchData=
[
  ['r1_0',['r1',['../classfacade_1_1_sistema_de_restaurantes.html#ac0b328fde086ddcb973ac10e80f0ad6c',1,'facade::SistemaDeRestaurantes']]],
  ['r2_1',['r2',['../classfacade_1_1_sistema_de_restaurantes.html#aba64739f46dd6023314a8713ba859fbd',1,'facade::SistemaDeRestaurantes']]],
  ['restaurantes_2',['restaurantes',['../classfacade_1_1_app_facade.html#a6ccd511804348ef88774fb01e99745ee',1,'facade::AppFacade']]]
];
